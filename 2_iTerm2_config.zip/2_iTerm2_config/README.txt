# Para instalar, copiar en el directorio $HOME dotfiles y dotfiles.tar.gz

# Rutas
brew path: /usr/local/Cellar
cask path: /opt/homebrew-cask/Casktoom
npm path: /usr/local/lib/node_modules